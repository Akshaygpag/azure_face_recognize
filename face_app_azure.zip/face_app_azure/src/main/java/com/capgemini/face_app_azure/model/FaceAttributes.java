package com.capgemini.face_app_azure.model;

import java.io.Serializable;

public class FaceAttributes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private float smile;
	private String gender;
	private float age;
	private Emotion emotion;
	private Blur blur;
	@Override
	public String toString() {
		return "FaceAttributes [smile=" + smile + ", gender=" + gender + ", age=" + age + ", emotion=" + emotion
				+ ", blur=" + blur + "]";
	}
	public FaceAttributes() {
		super();
		// TODO Auto-generated constructor stub
	}
	public float getSmile() {
		return smile;
	}
	public void setSmile(float smile) {
		this.smile = smile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public Emotion getEmotion() {
		return emotion;
	}
	public void setEmotion(Emotion emotion) {
		this.emotion = emotion;
	}
	public Blur getBlur() {
		return blur;
	}
	public void setBlur(Blur blur) {
		this.blur = blur;
	}

}
