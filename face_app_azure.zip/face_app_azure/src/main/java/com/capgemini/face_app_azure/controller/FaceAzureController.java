package com.capgemini.face_app_azure.controller;

import java.awt.Color;
import java.awt.Panel;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import org.apache.catalina.startup.FailedContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.face_app_azure.model.FaceEntity;
import com.capgemini.face_app_azure.service.FaceApiService;
import com.capgemini.face_app_azure.util.Utility;

@RestController
public class FaceAzureController {

	@Autowired
	private FaceApiService FaceApiService;

	@PostMapping("detect/faces")
	public Object faceDetection(String imageUrl) {

		String data = null;
		try {
			data = FaceApiService.detectFaceApi(imageUrl);
			List<FaceEntity> da = Utility.convertStringToObject(data, List.class,FaceEntity.class);
System.out.println(da);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	private void frameBuilder() {
		Panel thePanel = new Panel();
		JFrame frame = new JFrame("face detection");
		thePanel.setBackground(Color.WHITE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0, 300, 300);
		frame.add(
				new JLabel(new ImageIcon("https://fortunedotcom.files.wordpress.com/2018/07/gettyimages-961697338.jpg"),
						SwingConstants.CENTER));
		frame.add(thePanel);
		frame.setVisible(true);
	}

}
