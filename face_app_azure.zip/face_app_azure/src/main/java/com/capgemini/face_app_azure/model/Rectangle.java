package com.capgemini.face_app_azure.model;

import java.io.Serializable;

public class Rectangle implements Serializable {

	@Override
	public String toString() {
		return "Rectangle [left=" + left + ", width=" + width + ", height=" + height + ", top=" + top + "]";
	}

	public Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int left, width, height, top;

	public int getLeft() {
		return left;
	}

	public void setLeft(int left) {
		this.left = left;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getTop() {
		return top;
	}

	public void setTop(int top) {
		this.top = top;
	}
}
