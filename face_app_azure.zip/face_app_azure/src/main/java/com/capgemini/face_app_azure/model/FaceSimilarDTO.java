package com.capgemini.face_app_azure.model;

import java.io.Serializable;

public class FaceSimilarDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String 
	
	{
	    "faceId": "c5c24a82-6845-4031-9d5d-978df9175426",
	    "largeFaceListId": "sample_list",
	    "maxNumOfCandidatesReturned": 10,
	    "mode": "matchPerson"
	}
	
}
