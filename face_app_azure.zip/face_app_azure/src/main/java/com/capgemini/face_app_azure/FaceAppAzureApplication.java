package com.capgemini.face_app_azure;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class FaceAppAzureApplication {

	public static void main(String[] args) {
//		SpringApplication.run(FaceAppAzureApplication.class, args);

		SpringApplicationBuilder builder = new SpringApplicationBuilder(FaceAppAzureApplication.class);
		builder.headless(false).run(args);

	}
}
