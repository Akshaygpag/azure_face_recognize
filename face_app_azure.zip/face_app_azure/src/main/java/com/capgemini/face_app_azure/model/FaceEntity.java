package com.capgemini.face_app_azure.model;

import java.io.Serializable;

public class FaceEntity implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private String faceId;
	private Rectangle faceRectangle;
	private FaceAttributes faceAttributes;

	@Override
	public String toString() {
		return "FaceEntity [faceId=" + faceId + ", faceRectangle=" + faceRectangle + ", faceAttributes="
				+ faceAttributes + "]";
	}

	public FaceEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFaceId() {
		return faceId;
	}

	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}

	public Rectangle getFaceRectangle() {
		return faceRectangle;
	}

	public void setFaceRectangle(Rectangle faceRectangle) {
		this.faceRectangle = faceRectangle;
	}

	public FaceAttributes getFaceAttributes() {
		return faceAttributes;
	}

	public void setFaceAttributes(FaceAttributes faceAttributes) {
		this.faceAttributes = faceAttributes;
	}
}
