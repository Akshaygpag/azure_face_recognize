package com.capgemini.face_app_azure.model;

import java.io.Serializable;

public class Blur implements Serializable {
	@Override
	public String toString() {
		return "Blur [blurLevel=" + blurLevel + ", value=" + value + "]";
	}

	public Blur() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private String blurLevel;
	private double value;

	public String getBlurLevel() {
		return blurLevel;
	}

	public void setBlurLevel(String blurLevel) {
		this.blurLevel = blurLevel;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
}
